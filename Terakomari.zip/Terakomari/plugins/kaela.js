import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.xyroinee.xyz/api/sfw/Kaela?apikey=SSCyfcnnSf`
	conn.sendFile(m.chat, url, '', '_Nih Kak_', m)
}
handler.command = /^(kaela)$/i
handler.tags = ['anime']
handler.help = ['kaela']
handler.limit = true
export default handler