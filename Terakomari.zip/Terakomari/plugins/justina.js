import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.zahwazein.xyz/randomasupan/justina?apikey=zenzkey_01e583a0f2`
	conn.sendFile(m.chat, url, '', '_Nih Kak_', m)
}
handler.command = /^(justina)$/i
handler.tags = ['random']
handler.help = ['justina']
handler.limit = true
export default handler