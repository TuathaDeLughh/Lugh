import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.zahwazein.xyz/randomanime/megumin?apikey=zenzkey_01e583a0f2`
	conn.sendFile(m.chat, url, 'anu.jpg', '_Nih Kak_', m)
}
handler.command = /^(megumin)$/i
handler.tags = ['anime']
handler.help = ['megumin']
handler.premium = false
handler.limit = true

export default handler