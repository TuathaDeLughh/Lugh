import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.xyroinee.xyz/api/asupan/image/japan?apikey=SSCyfcnnSf`
	conn.sendFile(m.chat, url, '', '_Random Cosplay_', m)
}
handler.command = /^(cecanjepang)$/i
handler.tags = ['random']
handler.help = ['cecanjepang']
handler.limit = true
export default handler