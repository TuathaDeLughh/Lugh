import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.zahwazein.xyz/randomimage/boneka?apikey=zenzkey_01e583a0f2`
	conn.sendFile(m.chat, url, '', '_Nih Kak_', m)
}
handler.command = /^(boneka)$/i
handler.tags = ['anime']
handler.help = ['boneka']
handler.limit = true
export default handler