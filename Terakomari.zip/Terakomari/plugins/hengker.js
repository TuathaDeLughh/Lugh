import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.zahwazein.xyz/randomimage/hacker?apikey=zenzkey_01e583a0f2`
	conn.sendFile(m.chat, url, '', '_Nih Kak_', m)
}
handler.command = /^(hacker|hengker)$/i
handler.tags = ['anime']
handler.help = ['hacker']
handler.limit = true
export default handler