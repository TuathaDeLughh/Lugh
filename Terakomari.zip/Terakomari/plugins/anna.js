import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.xyroinee.xyz/api/sfw/anna?apikey=SSCyfcnnSf`
	conn.sendFile(m.chat, url, '', '_Nih Kak_', m)
}
handler.command = /^(anna)$/i
handler.tags = ['anime']
handler.help = ['anna']
handler.limit = true
export default handler