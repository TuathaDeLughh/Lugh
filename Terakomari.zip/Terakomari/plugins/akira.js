import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.xyroinee.xyz/api/sfw/akira?apikey=SSCyfcnnSf`
	conn.sendFile(m.chat, url, '', '_Nih Kak_', m)
}
handler.command = /^(akira)$/i
handler.tags = ['anime']
handler.help = ['akira']
handler.limit = true
export default handler