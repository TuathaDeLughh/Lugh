
let handler = async (m, { conn }) => {

m.reply(`
≡  *DyLuxᴮᴼᵀ ┃ SUPPORT*

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Grupo *1*
${dygp}

▢ Grupo *2*
https://chat.whatsapp.com/I7bvd8XCAOUHjgkHteqFC7

▢ Grupo *NSFW* 🔞
https://chat.whatsapp.com/F0JTTyZ3hsoL7OlU8TEpuH

▢ 𝐌𝐘 - 𝐌𝐚𝐲𝐥𝐮𝐱 | ᴮᴼᵀ⚡
https://chat.whatsapp.com/CTILZXSriIE3M40anVyPT4

▢ 📲💻ANDROID WORLD🎬🎮
https://chat.whatsapp.com/Ly4I2LObSvW8VgOnJjofgA

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Todos los Grupos
 https://instabio.cc/fg98ff

▢ *Telegram*
• https://t.me/fgawgp
 ▢ *PayPal*
• https://paypal.me/fg98f
▢ *YouTube*
• https://www.youtube.com/fg98f`)

}
handler.help = ['support']
handler.tags = ['main']
handler.command = ['grupos', 'groupdylux', 'dxgp', 'dygp', 'gpdylux', 'support'] 

export default handler
