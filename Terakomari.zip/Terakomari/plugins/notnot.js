import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.zahwazein.xyz/randomasupan/notnot?apikey=zenzkey_01e583a0f2`
	conn.sendFile(m.chat, url, '', '_Nih Kak_', m)
}
handler.command = /^(notnot)$/i
handler.tags = ['random']
handler.help = ['notnot']
handler.limit = true
export default handler