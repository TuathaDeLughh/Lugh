import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.xyroinee.xyz/api/sfw/Chisato?apikey=SSCyfcnnSf`
	conn.sendFile(m.chat, url, '', '_Nih Kak_', m)
}
handler.command = /^(chisato)$/i
handler.tags = ['anime']
handler.help = ['chisato']
handler.limit = true
export default handler