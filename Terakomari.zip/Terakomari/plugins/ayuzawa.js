import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {
	let url = `https://api.xyroinee.xyz/api/sfw/Ayuzawa?apikey=SSCyfcnnSf`
	conn.sendFile(m.chat, url, '', '_Nih Kak_', m)
}
handler.command = /^(ayuzawa)$/i
handler.tags = ['anime']
handler.help = ['ayuzawa']
handler.limit = true
export default handler